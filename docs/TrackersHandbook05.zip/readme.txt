Well here it is! version 0.5 of The Book. It's been much harder
this time - lack of contributions and my inspiration is failing :v( Anyway - heres whats new:

Stuff on Panning
Stuff on EQ
More internet stuff
Other stuff that i did 6 months ago and have forgotten :v)
Massive amount of subtle changes in grammar to improve readability

I don't know when the next version will get released - hopefully this will prompt people into sending me ideas and contributions etc

Enjoy!

Cools

Iformation on the HTML Version
==============================
This version uses JavaScript and Cascading Style Sheets (CSS). For full Viewing-comfort
try to get MSIE 4 or Navigator 4.05 (or above), else you'll miss the new style...

Browser Compatibility :

Netscape Navigator 4.5 : Everything Looks Fine .
Netscape Navigator 4.05 : Everything Looks Fine .
Netscape Navigator 3.0 Gold : Everything Looks Fine but the CSS doesn't work.
MS Internet Explorer 4.0 : Everything Looks Fine .
MS Internet Explorer 3.0 : Some space characters are shown as rectangles. This can be solved this way : View / Options / Advanced . Deactivate
                           the "Use Style Sheets" option . Now everything looks fine :-)
Opera 3.21 : Everything Looks Fine but the JavaScript-Buttons and the CSS dont work.
NCSA Mosaic 3.0 : Only the links are shown (!!!) . No text . No frame support . I'll see what we can do .
Lynx : It looks good but try each .htm file individually . No frames , no colours
, no graphs . Welcome to Unix :-)


Best Viewed : 800x600 or higher , 256 colors or more. Hyperlinks are Italic and Bold.