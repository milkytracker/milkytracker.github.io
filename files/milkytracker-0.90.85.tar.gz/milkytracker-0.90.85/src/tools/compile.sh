#!/bin/bash
g++ test.cpp 